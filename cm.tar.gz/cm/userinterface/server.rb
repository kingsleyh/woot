require 'sinatra'

set :public_folder, 'app'

get '/' do
  File.read(File.join('app', 'index.html'))
end

get '/cm/explain/latest/csa/:csa_id/:methodology' do
  File.read(File.join('app', 'ds2_explain.json'))
end

get '/auth/whoami' do
  "You are kingsley.hendrickse@db.com with GA token 2T8c45793aaa2a069e0ad5fc49b6b5f16e, with groups [<IT Support>, CHANGE APPROVER ROLE, FUSE EM BUSINESS ROLE, FUSE EQUITIES BUSINESS ROLE, FUSE FX BUSINESS ROLE, FUSE GENERATION ROLE, FUSE PUBLISHER ROLE, FUSE QUALITYCONTROL BUSINESS ROLE, FUSE RATES BUSINESS ROLE, FUSE UPLOAD COUNTERPARTIES ROLE, FUSE VIEW CSA REPORT, SUPPORT, VIEW PROPOSED CHANGES]"
end