package com.db.fuse.cm.userinterface;

public class UI {

    public static String indexPage() {
        return "<!DOCTYPE html>\n" +
                "<!--[if lt IE 7]>\n" +
                "<html lang=\"en\" ng-app=\"fuseApp\" class=\"no-js lt-ie9 lt-ie8 lt-ie7\"> <![endif]-->\n" +
                "<!--[if IE 7]>\n" +
                "<html lang=\"en\" ng-app=\"fuseApp\" class=\"no-js lt-ie9 lt-ie8\"> <![endif]-->\n" +
                "<!--[if IE 8]>\n" +
                "<html lang=\"en\" ng-app=\"fuseApp\" class=\"no-js lt-ie9\"> <![endif]-->\n" +
                "<!--[if gt IE 8]><!-->\n" +
                "<html lang=\"en\" ng-app=\"fuseApp\" class=\"no-js\"> <!--<![endif]-->\n" +
                "<head>\n" +
                "    <meta charset=\"utf-8\">\n" +
                "    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\n" +
                "    <title>Fuse</title>\n" +
                "    <meta name=\"description\" content=\"\">\n" +
                "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
                "    <link rel=\"stylesheet\" href=\"userinterface/app/lib/html5-boilerplate-4.3.0/css/normalize.css\">\n" +
                "    <link rel=\"stylesheet\" href=\"userinterface/app/lib/html5-boilerplate-4.3.0/css/main.css\">\n" +
                "    <link rel=\"stylesheet\" href=\"userinterface/app/css/app.css\">\n" +
                "    <link rel=\"stylesheet\" href=\"userinterface/app/lib/bootstrap-3.3.2-dist/css/bootstrap.css\">\n" +
                "    <link rel=\"stylesheet\" href=\"userinterface/app/lib/DataTables-1.9.4/media/css/demo_table.css\">\n" +
                "    <link rel=\"stylesheet\" href=\"userinterface/app/lib/DataTables-1.9.4/media/css/demo_table_jui.css\">\n" +
                "    <script src=\"userinterface/app/lib/html5-boilerplate-4.3.0/js/vendor/modernizr-2.6.2.min.js\"></script>\n" +
                "</head>\n" +
                "<body ng-cloak>\n" +
                "\n" +
                "<!--[if lt IE 7]>\n" +
                "<p class=\"browsehappy\">You are using an <strong>outdated</strong> browser. Please <a href=\"http://browsehappy.com/\">upgrade\n" +
                "    your browser</a> to improve your experience.</p>\n" +
                "<![endif]-->\n" +
                "\n" +
                "<!-- Header -->\n" +
                "<div ng-controller=\"NavController\" id=\"top-nav\" class=\"navbar navbar-inverse navbar-static-top\">\n" +
                "    <div class=\"container-fluid\">\n" +
                "        <div class=\"navbar-header\">\n" +
                "            <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">\n" +
                "                <span class=\"icon-bar\"></span>\n" +
                "                <span class=\"icon-bar\"></span>\n" +
                "                <span class=\"icon-bar\"></span>\n" +
                "                <span class=\"icon-bar\"></span>\n" +
                "            </button>\n" +
                "            <a class=\"navbar-brand\" href=\"#\"><img src=\"userinterface/app/img/fuse.png\"></a>\n" +
                "        </div>\n" +
                "        <div class=\"navbar-collapse collapse\">\n" +
                "            <ul class=\"nav navbar-nav navbar-right\">\n" +
                "                <li><a href=\"#\"><i class=\"glyphicon glyphicon-user\"></i><span> {{ user }}</span></a></li>\n" +
                "            </ul>\n" +
                "        </div>\n" +
                "    </div>\n" +
                "    <!-- /container -->\n" +
                "</div>\n" +
                "<!-- /Header -->\n" +
                "\n" +
                "<!-- Main -->\n" +
                "<div class=\"container-fluid\">\n" +
                "    <div class=\"row\">\n" +
                "        <div class=\"col-sm-3\">\n" +
                "            <!-- Left column -->\n" +
                "            <ul class=\"list-unstyled\">\n" +
                "                <li class=\"active\"><a href=\"#\"><i class=\"glyphicon glyphicon-home\"></i> Home</a></li>\n" +
                "            </ul>\n" +
                "            <hr>\n" +
                "\n" +
                "        </div>\n" +
                "        <!-- /col-3 -->\n" +
                "        <div ng-controller=\"ExplainController\" class=\"col-sm-9\">\n" +
                "\n" +
                "            <a href=\"#\"><strong><i class=\"glyphicon glyphicon-comment\"></i> Funding Name Generation Explain</strong></a>\n" +
                "\n" +
                "            <hr>\n" +
                "\n" +
                "            <div class=\"row\">\n" +
                "                <div class=\"col-md-6\">\n" +
                "                    <div class=\"panel panel-default\">\n" +
                "                        <div class=\"panel-body\">\n" +
                "\n" +
                "                            <form ng-submit=\"submit()\" class=\"navbar-form navbar-left\" role=\"search\">\n" +
                "                                <div class=\"form-group\">\n" +
                "                                    <input ng-model=\"explainForm.csaId\" name=\"explain_csa\" id=\"explain_csa\" type=\"text\"\n" +
                "                                           class=\"form-control\"\n" +
                "                                           placeholder=\"Enter Csa Id\">\n" +
                "                                    <select class=\"form-control\" ng-model=\"explainForm.methodology\"\n" +
                "                                            ng-options=\"o as o for o in methodologies\"\n" +
                "                                            name=\"explain_methodology\" id=\"explain_methodology\"></select>\n" +
                "\n" +
                "                                </div>\n" +
                "                                <button class=\"btn btn-info\">Explain</button>\n" +
                "                            </form>\n" +
                "\n" +
                "                        </div>\n" +
                "                    </div>\n" +
                "                </div>\n" +
                "            </div>\n" +
                "\n" +
                "            <div ng-show=\"explainError\" class=\"row\">\n" +
                "                <div class=\"col-md-12\">\n" +
                "                    <div class=\"alert alert-danger\">\n" +
                "                        <span>{{ explainError }}</span>\n" +
                "                    </div>\n" +
                "                </div>\n" +
                "            </div>\n" +
                "\n" +
                "            <div ng-show=\"explain.loaded\" class=\"row\">\n" +
                "                <div class=\"col-md-12\">\n" +
                "                    <div class=\"panel panel-info\">\n" +
                "                        <div class=\"panel-heading\">\n" +
                "                            <h3 class=\"panel-title\">For CSA\n" +
                "                                <span class=\"label label-primary\">{{ explain.csaId }}</span> explain funding name: <span\n" +
                "                                        class=\"label label-primary\">{{ explain.explanation.result }}</span>\n" +
                "                            </h3>\n" +
                "                        </div>\n" +
                "                        <div class=\"panel-body\">\n" +
                "                            <h4>{{ explain.explanation.description }}</h4>\n" +
                "\n" +
                "                            <script type=\"text/ng-template\" id=\"explainTree\">\n" +
                "                                <ul>\n" +
                "                                    <span ng-bind-html=\"childStep.description | formatDescription\"></span>\n" +
                "                                    <span ng-bind-html=\"childStep.result | formatResult\"></span>\n" +
                "                                    <li ng-repeat=\"cs in childStep.childSteps\">\n" +
                "                                        <span ng-bind-html=\"cs.description | formatDescription\"></span>\n" +
                "                                        <span ng-bind-html=\"cs.result | formatResult\"></span>\n" +
                "                                    </li>\n" +
                "                                </ul>\n" +
                "                            </script>\n" +
                "\n" +
                "                            <ol>\n" +
                "                                <li ng-repeat=\"childStep in explain.explanation.childSteps\"\n" +
                "                                    ng-include=\"'explainTree'\"></li>\n" +
                "                            </ol>\n" +
                "\n" +
                "                        </div>\n" +
                "                    </div>\n" +
                "                </div>\n" +
                "            </div>\n" +
                "        </div>\n" +
                "        <!--/col-span-9-->\n" +
                "    </div>\n" +
                "</div>\n" +
                "<!-- /Main -->\n" +
                "\n" +
                "\n" +
                "<!-- script references -->\n" +
                "<script src=\"userinterface/app/lib/jquery-1.11.2/jquery-1.11.2.js\"></script>\n" +
                "<script src=\"userinterface/app/lib/DataTables-1.9.4/media/js/jquery.dataTables.min.js\"></script>\n" +
                "<script src=\"userinterface/app/lib/underscore-1.7.0.js\"></script>\n" +
                "<script src=\"userinterface/app/lib/underscore.string.js\"></script>\n" +
                "<script src=\"userinterface/app/lib/bootstrap-3.3.2-dist/js/bootstrap.js\"></script>\n" +
                "<script src=\"userinterface/app/lib/angular-1.3.11/angular.js\"></script>\n" +
                "<script src=\"userinterface/app/lib/angular-1.3.11/angular-resource.js\"></script>\n" +
                "<script src=\"userinterface/app/lib/angular-1.3.11/angular-sanitize.js\"></script>\n" +
                "<script src=\"userinterface/app/js/app.js\"></script>\n" +
                "<script src=\"userinterface/app/js/services/UserService.js\"></script>\n" +
                "<script src=\"userinterface/app/js/services/ExplainService.js\"></script>\n" +
                "<script src=\"userinterface/app/js/controllers/NavController.js\"></script>\n" +
                "<script src=\"userinterface/app/js/controllers/ExplainController.js\"></script>\n" +
                "<script src=\"userinterface/app/js/filters.js\"></script>\n" +
                "<script src=\"userinterface/app/js/scripts.js\"></script>\n" +
                "\n" +
                "</body>\n" +
                "</html>";
    }

}
