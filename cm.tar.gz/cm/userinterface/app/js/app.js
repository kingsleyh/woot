'use strict';

var fuseApp = angular.module('fuseApp', ['ngResource','ngRoute']);

fuseApp.config(['$routeProvider',
    function($routeProvider) {
        $routeProvider.
            when('/csaExplain', {
                templateUrl: 'templates/csa-explain.html',
                controller: 'ExplainController'
            }).
            when('/shortCodeExplain', {
                templateUrl: 'templates/shortcode-explain.html',
                controller: 'ExplainController'
            }).
            otherwise({
                redirectTo: '/csaExplain'
            });
    }]);