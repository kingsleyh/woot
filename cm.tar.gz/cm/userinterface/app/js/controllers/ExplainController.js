'use strict';

fuseApp.controller('ExplainController',
    function NavController($scope, $location, explainService) {

        $scope.methodologies = ['DS2', 'DS25'];
        $scope.explainForm = {};
        $scope.explainForm.methodology = $scope.methodologies[0];
        $scope.explainForm.csaId = '';
        $scope.explain = {};
        $scope.explain.loaded = false;


        $scope.submit = function () {
            $scope.explain = explainService.get({
                    csaId: $scope.explainForm.csaId, methodology: $scope.explainForm.methodology
                },
                function (d) {
                    $scope.explainError = undefined;
                    d.loaded = true
                },function(error){
                    $scope.explainError = 'Error: ' + error.status + ' : ' + error.statusText;
                });
        };

    }
);