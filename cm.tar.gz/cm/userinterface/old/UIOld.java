//package com.db.fuse.cm.userinterface;
//
//public class UIOld {
//
//    public static String indexPage() {
//        return "<!DOCTYPE html>\n" +
//                "<html>\n" +
//                "<head>\n" +
//                "    <title>Fuse 2.0</title>\n" +
//                "\n" +
//                "    <meta charset=\"utf-8\" />\n" +
//                "    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge, chrome=1\" />\n" +
//                "    <meta name=\"apple-mobile-web-app-capable\" content=\"yes\" />\n" +
//                "    <meta name=\"apple-mobile-web-app-status-bar-style\" content=\"black\" />\n" +
//                "    <meta name=\"format-detection\" content=\"telephone=no\"/>\n" +
//                "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n" +
//                "\n" +
//                "    <link rel=\"stylesheet\" href=\"userinterface/lib/bootstrap/css/bootstrap.css\" />\n" +
//                "    <link rel=\"stylesheet\" href=\"userinterface/lib/jasny-bootstrap/css/jasny-bootstrap.css\" />\n" +
//                "    <link rel=\"stylesheet\" href=\"userinterface/lib/font-awesome/css/font-awesome.css\" />\n" +
//                "    <link rel=\"stylesheet\" href=\"userinterface/css/ie10mobile.css\" />\n" +
//                "    <link rel=\"stylesheet\" href=\"userinterface/lib/durandal/css/durandal.css\" />\n" +
//                "    <link rel=\"stylesheet\" href=\"userinterface/css/fuse.css\" />\n" +
//                "    <link rel=\"stylesheet\" href=\"userinterface/lib/DataTables-1.9.4/media/css/demo_table_jui.css\"/>\n" +
//                "    <link rel=\"stylesheet\" href=\"userinterface/lib/DataTables-1.9.4/media/css/demo_table.css\"/>\n" +
//                "    <link rel=\"stylesheet\" href=\"userinterface/lib/bootstrap/plugins/select2/css/select2.css\"/>\n" +
//                "    <link rel=\"stylesheet\" href=\"userinterface/lib/datetimepicker/jquery.datetimepicker.css\" />\n" +
//                "\n" +
//                "    <meta charset=\"utf-8\">\n" +
//                "    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=Edge\">\n" +
//                "    <!--[if (gte IE 6)&(lte IE 8)]>\n" +
//                "    <script type=\"text/javascript\" src=\"userinterface/ie_support/selectivizr.js\"></script>\n" +
//                "    <![endif]-->\n" +
//                "    <!--[if lt IE 9]>\n" +
//                "    <script type=\"text/javascript\" src=\"userinterface/ie_support/respond.js\"></script>\n" +
//                "    <script type=\"text/javascript\" src=\"\"></script>\n" +
//                "    <script type=\"text/javascript\" src=\"//html5shiv.googlecode.com/svn/trunk/html5.js\"></script>\n" +
//                "    <![endif]-->\n" +
//                "\n" +
//                "    <script type=\"text/javascript\">\n" +
//                "        if (navigator.userAgent.match(/IEMobile\\/10\\.0/)) {\n" +
//                "            var msViewportStyle = document.createElement(\"style\");\n" +
//                "            var mq = \"@@-ms-viewport{width:auto!important}\";\n" +
//                "            msViewportStyle.appendChild(document.createTextNode(mq));\n" +
//                "            document.getElementsByTagName(\"head\")[0].appendChild(msViewportStyle);\n" +
//                "        }\n" +
//                "    </script>\n" +
//                "\n" +
//                "</head>\n" +
//                "<body>\n" +
//                "<div id=\"applicationHost\">\n" +
//                "    <div class=\"splash\">\n" +
//                "        <div class=\"message\">\n" +
//                "            Fuse 2.0\n" +
//                "        </div>\n" +
//                "        <i class=\"icon-spinner icon-2x icon-spin active\"></i>\n" +
//                "    </div>\n" +
//                "</div>\n" +
//                "<script src=\"userinterface/lib/require/require.js\" data-main=\"userinterface/app/main\"></script>\n" +
//                "</body>\n" +
//                "</html>";
//    }
//
//}
