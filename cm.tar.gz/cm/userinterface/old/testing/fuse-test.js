(function () {
    "use strict";

//    function waitFor(test, expected_id, expected_text) {
//        return function () {
//            test.pause();
//            var deferred = Q.defer();
//            var interval = setInterval(loadPage, 3000);
//
//            function loadPage() {
//                var assertion = $('#testing').contents().find(expected_id).text() == expected_text;
//                if (assertion) {
//                    test.resume();
//                    deferred.resolve('finished loading');
//                    clearInterval(interval);
//                }
//            }
//
//            return deferred.promise;
//        };
//    }

    function waitFor(test,expected_id,expected_text){
        return function(){
            test.pause();
            var deferred = Q.defer();
            setTimeout(function loadPage() {
                var assertion = $('#testing').contents().find(expected_id).text() == expected_text;
                if (assertion) {
                    deferred.resolve('finished loading');
                    test.resume();
                } else {
                    setTimeout(loadPage, 1800);
                }
            }, 1800);
            return deferred.promise;
        };
    }

    function navigateTo(url) {
        return function () {
            return $('#testing').attr('src', url);
        };
    }

    function app() {
        return $('#testing').contents();
    }

    function clickPendingCsa(csaId) {
        return  app().find('#action_view_' + csaId)[0].click();
    }

    hiro.module("BasicUiTests", {
        setUp: function () {
            sessionStorage.setItem('fuse[in_test_mode]', 'true');
            sessionStorage.setItem('fuse[pending_csa_data]', new TestJson().pendingCsas());
        },

        testPendingCsaScreenE2E: function (test) {
            Q.longStackSupport = true;
            Q.fcall(navigateTo('/index.html'))
                .then(function(){ return test.pause();})
                .then(waitFor(test, '#area-header', "Credit Support Annexes (CSA) - Pending"))
                .then(function () {
                    test.assertEqual("View", app().find('#action_view_263').text());
                    test.assertEqual("View", app().find('#action_view_263').text());
                    clickPendingCsa('263');
                })
                .then(waitFor(test, '#sub_row_263', "263"))
                .then(function () {
                    test.assertEqual("BILATERAL", app().find('#reciprocity_v_263').text());
                    clickPendingCsa('263');
                })
                .then(navigateTo('/index.html#admin'))
                .done(function(){ return test.resume();});
        }

    });

    function TestJson() {
        var self = this;
        self.pendingCsas = function () {
            return JSON.stringify([
                {
                    "csaId": "263",
                    "changeId": "263:1403258287825",
                    "proposed": {
                        "principals": [
                            {
                                "paragonId": "145"
                            },
                            {
                                "paragonId": "157"
                            },
                            {
                                "paragonId": "177"
                            },
                            {
                                "paragonId": "248"
                            },
                            {
                                "paragonId": "415"
                            },
                            {
                                "paragonId": "432"
                            }
                        ],
                        "counterparties": [
                            {
                                "paragonId": "477"
                            },
                            {
                                "paragonId": "5554044"
                            },
                            {
                                "paragonId": "5994525"
                            },
                            {
                                "paragonId": "6574008"
                            },
                            {
                                "paragonId": "6925284"
                            }
                        ],
                        "reciprocity": "BILATERAL",
                        "isLive": true,
                        "agreementStatus": "APPROVED",
                        "documentType": "CSA ENGLISH LAW",
                        "scope": "POOL",
                        "isCleared": false,
                        "eligibleAssets": [
                            {
                                "asset": "CASH-EUR",
                                "bps": {
                                    "spread": 0,
                                    "effectiveFrom": "2010-02-03"
                                }
                            },
                            {
                                "asset": "CASH-MOO",
                                "bps": {
                                    "spread": 0,
                                    "effectiveFrom": "2010-02-03"
                                }
                            },
                            {
                                "asset": "CASH-USD",
                                "bps": {
                                    "spread": 0,
                                    "effectiveFrom": "2009-08-21"
                                }
                            },
                            {
                                "asset": "CASH-EUR",
                                "bps": {
                                    "spread": 0,
                                    "effectiveFrom": "2010-02-03"
                                }
                            }
                        ],
                        "thresholds": {
                            "counterparty": {
                                "threshold": 1,
                                "currency": "GBP"
                            },
                            "principal": {
                                "threshold": 2,
                                "currency": "USD"
                            }
                        },
                        "fundingNames": {
                            "ds2": "csa-2way-eur-cash",
                            "ds25": "csa-2way-eur-cash",
                            "ds3": "csa-2way-eur-cash"
                        },
                        "products": [],
                        "trades": [
                            {
                                "sourceSystem": "summit",
                                "tradeId": "123456"
                            }
                        ]
                    },
                    "approved": {
                        "principals": [
                            {
                                "paragonId": "145"
                            },
                            {
                                "paragonId": "157"
                            },
                            {
                                "paragonId": "177"
                            },
                            {
                                "paragonId": "248"
                            },
                            {
                                "paragonId": "415"
                            },
                            {
                                "paragonId": "432"
                            }
                        ],
                        "counterparties": [
                            {
                                "paragonId": "477"
                            },
                            {
                                "paragonId": "5554044"
                            },
                            {
                                "paragonId": "5994525"
                            },
                            {
                                "paragonId": "6574008"
                            },
                            {
                                "paragonId": "6925284"
                            }
                        ],
                        "reciprocity": "BILATERAL",
                        "isLive": true,
                        "agreementStatus": "APPROVED",
                        "documentType": "CSA ENGLISH LAW",
                        "scope": "POOL",
                        "isCleared": false,
                        "eligibleAssets": [
                            {
                                "asset": "CASH-EUR",
                                "bps": {
                                    "spread": 0,
                                    "effectiveFrom": "2010-02-03"
                                }
                            },
                            {
                                "asset": "CASH-USD",
                                "bps": {
                                    "spread": 0,
                                    "effectiveFrom": "2010-02-03"
                                }
                            },
                            {
                                "asset": "CASH-USD",
                                "bps": {
                                    "spread": 0,
                                    "effectiveFrom": "2009-08-21"
                                }
                            },
                            {
                                "asset": "CASH-EUR",
                                "bps": {
                                    "spread": 0,
                                    "effectiveFrom": "2010-02-03"
                                }
                            }
                        ],
                        "thresholds": {
                            "counterparty": {
                                "threshold": 0,
                                "currency": "USD"
                            },
                            "principal": {
                                "threshold": 0,
                                "currency": "USD"
                            }
                        },
                        "fundingNames": {
                            "ds2": "csa-2way-eur-cash",
                            "ds25": "csa-cp-post-eur-cash",
                            "ds3": "csa-cp-post-eur-cash"
                        },
                        "products": [],
                        "trades": [
                            {
                                "sourceSystem": "summit",
                                "tradeId": "123456"
                            }
                        ]
                    }
                },
                {
                    "csaId": "104941",
                    "changeId": "104941:1403258148568",
                    "approved": {
                        "principals": [
                            {
                                "paragonId": "177"
                            }
                        ],
                        "counterparties": [
                            {
                                "paragonId": "477"
                            }
                        ],
                        "reciprocity": "BILATERAL",
                        "isLive": true,
                        "agreementStatus": "APPROVED",
                        "documentType": "LONG FORM CONFIRMATION",
                        "scope": "STANDALONE",
                        "isCleared": false,
                        "eligibleAssets": [
                            {
                                "asset": "CASH-USD",
                                "bps": {
                                    "spread": 0,
                                    "effectiveFrom": "2012-09-24"
                                }
                            },
                            {
                                "asset": "CASH-GBP",
                                "bps": {
                                    "spread": 0,
                                    "effectiveFrom": "2012-09-24"
                                }
                            },
                            {
                                "asset": "CASH-USD",
                                "bps": {
                                    "spread": 0,
                                    "effectiveFrom": "2012-09-24"
                                }
                            }
                        ],
                        "thresholds": {
                            "counterparty": {
                                "threshold": 0,
                                "currency": "EUR"
                            },
                            "principal": {
                                "threshold": "Infinity",
                                "currency": "EUR"
                            }
                        },
                        "fundingNames": {
                            "ds2": "csa-cp-post-eur-cash",
                            "ds25": "csa-cp-post-eur-cash",
                            "ds3": "csa-cp-post-eur-cash"
                        },
                        "products": []
                    }
                },
                {
                    "csaId": "106549",
                    "changeId": "106549:1403258148568",
                    "proposed": {
                        "principals": [
                            {
                                "paragonId": "145"
                            },
                            {
                                "paragonId": "157"
                            },
                            {
                                "paragonId": "177"
                            },
                            {
                                "paragonId": "248"
                            },
                            {
                                "paragonId": "415"
                            },
                            {
                                "paragonId": "432"
                            },
                            {
                                "paragonId": "5019"
                            },
                            {
                                "paragonId": "718"
                            }
                        ],
                        "counterparties": [
                            {
                                "paragonId": "1855"
                            }
                        ],
                        "reciprocity": "BILATERAL",
                        "isLive": true,
                        "agreementStatus": "APPROVED",
                        "documentType": "SCSA NEW YORK LAW SILO",
                        "scope": "POOL",
                        "isCleared": false,
                        "eligibleAssets": [
                            {
                                "asset": "CASH-EUR SCSA",
                                "bps": {
                                    "spread": 0,
                                    "effectiveFrom": "2012-12-10"
                                }
                            },
                            {
                                "asset": "CASH-USD SCSA",
                                "bps": {
                                    "spread": 0,
                                    "effectiveFrom": "2012-12-18"
                                }
                            }
                        ],
                        "thresholds": {
                            "counterparty": {
                                "threshold": 0,
                                "currency": "USD"
                            },
                            "principal": {
                                "threshold": 0,
                                "currency": "USD"
                            }
                        },
                        "fundingNames": {
                            "ds2": "csa-2way-eur-cash",
                            "ds25": "csa-2way-eur-cash",
                            "ds3": "csa-2way-eur-cash"
                        },
                        "products": []
                    }
                }
            ]);
        };
    };

})();