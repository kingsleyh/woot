require 'sinatra'

set :public_folder, File.dirname(__FILE__)

get '/stats' do
  'hello'
end