define(['plugins/http', 'knockout', 'plugins/router', 'plugins/koplus', 'plugins/jquery-diff'], function (http, ko, router) {
    return {
        fundingNames: fundingNames,
        thresholdData: thresholdData,
        assetData: assetData,
        dbEntities: dbEntities,
        parties: parties
    };

    function fundingNames(data) {
        var fundingNameJson = {'proposed': {
            'ds2': '',
            'ds25': '',
            'ds3': ''},
            'approved': {
                'ds2': '',
                'ds25': '',
                'ds3': ''
            },
            'css': {
                'approved': {
                    'ds2': '',
                    'ds25': '',
                    'ds3': ''
                },
                'proposed': {
                    'ds2': '',
                    'ds25': '',
                    'ds3': ''
                }
            }
        };
        if (hasNoApproved(data)) {
            if (hasNoProposed(data)) {
                return fundingNameJson;
            } else {
                fundingNameJson.proposed.ds2 = data.proposed.fundingNamesContext.fundingNames['ds2'];
                fundingNameJson.proposed.ds25 = data.proposed.fundingNamesContext.fundingNames['ds25'];
                fundingNameJson.proposed.ds3 = data.proposed.fundingNamesContext.fundingNames['ds3'];
                fundingNameJson.css.proposed.ds2 = 'label label-info';
                fundingNameJson.css.proposed.ds25 = 'label label-info';
                fundingNameJson.css.proposed.ds3 = 'label label-info';
                return fundingNameJson;
            }
        } else {
            if (hasNoProposed(data)) {
                fundingNameJson.approved.ds2 = data.approved.fundingNamesContext.fundingNames['ds2'];
                fundingNameJson.approved.ds25 = data.approved.fundingNamesContext.fundingNames['ds25'];
                fundingNameJson.approved.ds3 = data.approved.fundingNamesContext.fundingNames['ds3'];
                fundingNameJson.css.approved.ds2 = 'label label-warning';
                fundingNameJson.css.approved.ds25 = 'label label-warning';
                fundingNameJson.css.approved.ds3 = 'label label-warning';
                return fundingNameJson;
            } else {
                if (isOverride(data)) {
                    fundingNameJson.proposed.ds2 = data.proposed.fundingNamesContext.fundingNames['ds2'];
                    fundingNameJson.proposed.ds25 = data.proposed.fundingNamesContext.fundingNames['ds25'];
                    fundingNameJson.proposed.ds3 = data.proposed.fundingNamesContext.fundingNames['ds3'];
                    fundingNameJson.css.proposed.ds2 = 'label label-info';
                    fundingNameJson.css.proposed.ds25 = 'label label-info';
                    fundingNameJson.css.proposed.ds3 = 'label label-info';
                    return fundingNameJson;
                } else {
                    diff = calculateDiff(data.proposed.fundingNamesContext.fundingNames, data.approved.fundingNamesContext.fundingNames);

                    ds2 = hasData(diff['ds2']);
                    ds25 = hasData(diff['ds25']);
                    ds3 = hasData(diff['ds3']);

                    fundingNameJson.proposed.ds2 = data.proposed.fundingNamesContext.fundingNames['ds2'];
                    fundingNameJson.proposed.ds25 = data.proposed.fundingNamesContext.fundingNames['ds25'];
                    fundingNameJson.proposed.ds3 = data.proposed.fundingNamesContext.fundingNames['ds3'];

                    fundingNameJson.approved.ds2 = ds2 ? diff['ds2'][1] : data.proposed.fundingNamesContext.fundingNames['ds2'];
                    fundingNameJson.approved.ds25 = ds25 ? diff['ds25'][1] : data.proposed.fundingNamesContext.fundingNames['ds25'];
                    fundingNameJson.approved.ds3 = ds3 ? diff['ds3'][1] : data.proposed.fundingNamesContext.fundingNames['ds3'];

                    fundingNameJson.css.proposed.ds2 = ds2 ? 'label label-info' : '';
                    fundingNameJson.css.proposed.ds25 = ds25 ? 'label label-info' : '';
                    fundingNameJson.css.proposed.ds3 = ds3 ? 'label label-info' : '';

                    fundingNameJson.css.approved.ds2 = ds2 ? 'label label-warning' : '';
                    fundingNameJson.css.approved.ds25 = ds25 ? 'label label-warning' : '';
                    fundingNameJson.css.approved.ds3 = ds3 ? 'label label-warning' : '';
                    return fundingNameJson;
                }
            }
        }

    }

    function thresholdData(data) {
        var thresholdJson = {'proposed': {
            'counterparty_threshold': '',
            'counterparty_currency': '',
            'principal_threshold': '',
            'principal_currency': ''
        },
            'approved': {
                'counterparty_threshold': '',
                'counterparty_currency': '',
                'principal_threshold': '',
                'principal_currency': ''
            },
            'css': {
                'approved': {
                    'counterparty_threshold': '',
                    'counterparty_currency': '',
                    'principal_threshold': '',
                    'principal_currency': ''
                },
                'proposed': {
                    'counterparty_threshold': '',
                    'counterparty_currency': '',
                    'principal_threshold': '',
                    'principal_currency': ''
                }
            }
        };
        if (hasNoApproved(data)) {
            if (hasNoProposed(data)) {
                return thresholdJson;
            } else {
                if (isOverride(data)) {
                    return thresholdJson;
                } else {
                    thresholdJson.proposed.counterparty_threshold = data.proposed.thresholds.counterparty['threshold'];
                    thresholdJson.proposed.counterparty_currency = data.proposed.thresholds.counterparty['currency'];
                    thresholdJson.proposed.principal_threshold = data.proposed.thresholds.principal['threshold'];
                    thresholdJson.proposed.principal_currency = data.proposed.thresholds.principal['currency'];
                    thresholdJson.css.proposed.counterparty_threshold = 'label label-info';
                    thresholdJson.css.proposed.counterparty_currency = 'label label-info';
                    thresholdJson.css.proposed.principal_threshold = 'label label-info';
                    thresholdJson.css.proposed.principal_currency = 'label label-info';
                    return thresholdJson;
                }
            }
        } else {
            if (hasNoProposed(data)) {
                thresholdJson.approved.counterparty_threshold = data.approved.thresholds.counterparty['threshold'];
                thresholdJson.approved.counterparty_currency = data.approved.thresholds.counterparty['currency'];
                thresholdJson.approved.principal_threshold = data.approved.thresholds.principal['threshold'];
                thresholdJson.approved.principal_currency = data.approved.thresholds.principal['currency'];
                thresholdJson.css.approved.counterparty_threshold = 'label label-warning';
                thresholdJson.css.approved.counterparty_currency = 'label label-warning';
                thresholdJson.css.approved.principal_threshold = 'label label-warning';
                thresholdJson.css.approved.principal_currency = 'label label-warning';
                return thresholdJson;
            } else {
                if (isOverride(data)) {
                    return thresholdJson;
                } else {
                    diff = calculateDiff(data.proposed.thresholds, data.approved.thresholds);

                    counterparty_threshold = hasData(diff.counterparty['threshold']);
                    counterparty_currency = hasData(diff.counterparty['currency']);
                    principal_threshold = hasData(diff.principal['threshold']);
                    principal_currency = hasData(diff.principal['currency']);

                    thresholdJson.proposed.counterparty_threshold = data.proposed.thresholds.counterparty['threshold'];
                    thresholdJson.proposed.counterparty_currency = data.proposed.thresholds.counterparty['currency'];
                    thresholdJson.proposed.principal_threshold = data.proposed.thresholds.principal['threshold'];
                    thresholdJson.proposed.principal_currency = data.proposed.thresholds.principal['currency'];

                    thresholdJson.approved.counterparty_threshold = counterparty_threshold ? diff.counterparty['threshold'][1] : data.proposed.thresholds.counterparty['threshold'];
                    thresholdJson.approved.counterparty_currency = counterparty_currency ? diff.counterparty['currency'][1] : data.proposed.thresholds.counterparty['currency'];
                    thresholdJson.approved.principal_threshold = principal_threshold ? diff.principal['threshold'][1] : data.proposed.thresholds.principal['threshold'];
                    thresholdJson.approved.principal_currency = principal_currency ? diff.principal['currency'][1] : data.proposed.thresholds.principal['currency'];

                    thresholdJson.css.proposed.counterparty_threshold = counterparty_threshold ? 'label label-info' : '';
                    thresholdJson.css.proposed.counterparty_currency = counterparty_currency ? 'label label-info' : '';
                    thresholdJson.css.proposed.principal_threshold = principal_threshold ? 'label label-info' : '';
                    thresholdJson.css.proposed.principal_currency = principal_currency ? 'label label-info' : '';

                    thresholdJson.css.approved.counterparty_threshold = counterparty_threshold ? 'label label-warning' : '';
                    thresholdJson.css.approved.counterparty_currency = counterparty_currency ? 'label label-warning' : '';
                    thresholdJson.css.approved.principal_threshold = principal_threshold ? 'label label-warning' : '';
                    thresholdJson.css.approved.principal_currency = principal_currency ? 'label label-warning' : '';
                    return thresholdJson;
                }
            }
        }

    }

    function assetData(data) {
        var assetJson = function () {
            return {'proposed': {
                'assetType': '',
                'bps_spread': '',
                'date': '',
                'isSegregated':'',
                'isRehypo':''
            },
                'approved': {
                    'assetType': '',
                    'bps_spread': '',
                    'date': '',
                    'isSegregated':'',
                    'isRehypo':''
                },
                'css': {
                    'approved': {
                        'assetType': '',
                        'bps_spread': '',
                        'date': '',
                        'isSegregated':'',
                        'isRehypo':''
                    },
                    'proposed': {
                        'assetType': '',
                        'bps_spread': '',
                        'date': '',
                        'isSegregated':'',
                        'isRehypo':''
                    }
                }
            }
        };
        if (hasNoApproved(data)) {
            if (hasNoProposed(data)) {
                return [assetJson];
            } else {
                if (isOverride(data)) {
                    return [assetJson];
                } else {
                    return _.map(data.proposed.eligibleAssets(), function (a) {
                        var assetType = a.assetType == undefined ? "" : a.assetType();
                        var bps_spread = a.bps.spread == undefined ? "" : a.bps.spread();
                        var date = a.bps.effectiveFrom == undefined ? "" : a.bps.effectiveFrom();
                        var isSegregated = a.isCashSegregated == undefined ? "" : a.isCashSegregated();
                        var isRehypo = a.rehypothecationRights == undefined ? "" : a.rehypothecationRights();
                        var json = assetJson();
                        json.proposed.assetType = assetType;
                        json.proposed.bps_spread = bps_spread;
                        json.proposed.date = date;
                        json.proposed.isSegregated = isSegregated;
                        json.proposed.isRehypo = isRehypo;
                        json.css.proposed.assetType = 'label label-info';
                        json.css.proposed.bps_spread = 'label label-info';
                        json.css.proposed.date = 'label label-info';
                        json.css.proposed.isSegregated = 'label label-info';
                        json.css.proposed.isRehypo = 'label label-info';
                        return json;
                    });
                }
            }
        } else {
            if (hasNoProposed(data)) {
                return _.map(data.approved.eligibleAssets(), function (a) {
                    var asset = a.asset == undefined ? "" : a.asset;
                    var bps_spread = a.bps.spread == undefined ? "" : a.bps.spread;
                    var date = a.bps.effectiveFrom == undefined ? "" : a.bps.effectiveFrom;
                    var isSegregated = a.isCashSegregated == undefined ? "" : a.isCashSegregated();
                    var isRehypo = a.rehypothecationRights == undefined ? "" : a.rehypothecationRights();
                    var json = assetJson();
                    json.approved.asset = asset;
                    json.approved.bps_spread = bps_spread;
                    json.approved.date = date;
                    json.proposed.isSegregated = isSegregated;
                    json.proposed.isRehypo = isRehypo;
                    json.css.approved.asset = 'label label-warning';
                    json.css.approved.bps_spread = 'label label-warning';
                    json.css.approved.date = 'label label-warning';
                    json.css.proposed.isSegregated = 'label label-warning';
                    json.css.proposed.isRehypo = 'label label-warning';
                    return json;
                });
            } else {
                if (isOverride(data)) {
                    return [assetJson];
                } else {
                    var diff = calculateDiff(data.proposed.eligibleAssets, data.approved.eligibleAssets);

                    var count = 0;
                    return  _.map(diff, function (a) {
                        var asset = a.asset == undefined ? "" : a.asset;
                        var bps_spread = a.bps.spread == undefined ? "" : a.bps.spread;
                        var date = a.bps.effectiveFrom == undefined ? "" : a.bps.effectiveFrom;
                        var isSegregated = a.isCashSegregated == undefined ? "" : a.isCashSegregated();
                        var isRehypo = a.rehypothecationRights == undefined ? "" : a.rehypothecationRights();

                        var p_asset = data.proposed.eligibleAssets()[count].asset == undefined ? "" : data.proposed.eligibleAssets()[count].asset;
                        var p_bps_spread = data.proposed.eligibleAssets()[count].bps.spread == undefined ? "" : data.proposed.eligibleAssets()[count].bps.spread;
                        var p_date = data.proposed.eligibleAssets()[count].bps.effectiveFrom == undefined ? "" : data.proposed.eligibleAssets()[count].bps.effectiveFrom;
                        var p_isSegregated = data.proposed.eligibleAssets()[count].isSegregated == undefined ? "" : data.proposed.eligibleAssets()[count].isSegregated;
                        var p_isRehypo = data.proposed.eligibleAssets()[count].isRehypo == undefined ? "" : data.proposed.eligibleAssets()[count].isRehypo;

                        var diff_asset = hasData(asset);
                        var diff_bps_spread = hasData(bps_spread);
                        var diff_date = hasData(date);
                        var diff_isSegregated = hasData(isSegregated);
                        var diff_isRehypo = hasData(isRehypo);

                        var json = assetJson();

                        json.proposed.asset = p_asset;
                        json.proposed.bps_spread = p_bps_spread;
                        json.proposed.date = p_date;
                        json.proposed.isSegregated = p_isSegregated;
                        json.proposed.isRehypo = p_isRehypo;

                        json.approved.asset = diff_asset ? asset[1] : p_asset;
                        json.approved.bps_spread = diff_bps_spread ? bps_spread[1] : p_bps_spread;
                        json.approved.date = diff_date ? date[1] : p_date;
                        json.approved.isSegregated = diff_isSegregated ? isSegregated[1] : p_isSegregated;
                        json.approved.isRehypo = diff_isRehypo ? isRehypo[1] : p_isRehypo;

                        json.css.proposed.asset = diff_asset ? 'label label-info' : '';
                        json.css.proposed.bps_spread = diff_bps_spread ? 'label label-info' : '';
                        json.css.proposed.date = diff_date ? 'label label-info' : '';
                        json.css.proposed.isSegregated = diff_isSegregated ? 'label label-info' : '';
                        json.css.proposed.isRehypo = diff_isRehypo ? 'label label-info' : '';

                        json.css.approved.asset = diff_asset ? 'label label-warning' : '';
                        json.css.approved.bps_spread = diff_bps_spread ? 'label label-warning' : '';
                        json.css.approved.date = diff_date ? 'label label-warning' : '';
                        json.css.proposed.isSegregated = diff_isSegregated ? 'label label-warning' : '';
                        json.css.proposed.isRehypo = diff_isRehypo ? 'label label-warning' : '';

                        count = count + 1
                        return json;

                    });
                }
            }
        }
    }

    function dbEntities(data) {
        if (hasNoApproved(data)) {
            if (hasNoProposed(data)) {
                return {
                    'entities': {
                        'principals': [],
                        'counterparties': []
                    }
                }
            } else {
                return {
                    'entities': {
                        'principals': hasData(data.proposed.principals()) ? data.proposed.principals : [],
                        'counterparties': hasData(data.proposed.counterparties) ? _.map(data.proposed.counterparties, function (e) {
                            return '+' + e
                        }) : []
                    }
                }
            }
        } else {
            if (hasNoProposed(data)) {
                return {
                    'entities': {
                        'principals': principals ? data.approved.principals[1] : [],
                        'counterparties': counterparties ? data.approved.counterparties[1] : []
                    }
                }
            } else {
                diff = calculateDiff(data.proposed, data.approved);
                principals = hasData(diff.principals);
                counterparties = hasData(diff.counterparties);

                return {
                    'entities': {
                        'principals': principals ? diff.principals[1] : [],
                        'counterparties': counterparties ? diff.counterparties[1] : []
                    }
                }
            }
        }
    }


    function parties(data) {
        var partyJson = {'proposed': {
            'paragonId': ''},
            'approved': {
                'paragonId': ''
            },
            'css': {
                'approved': {
                    'paragonId': ''
                },
                'proposed': {
                    'paragonId': ''
                }
            }
        };
        if (hasNoApproved(data)) {
            if (hasNoProposed(data)) {
                return partyJson;
            } else {
                partyJson.proposed.paragonId = data.proposed.paragonId;
                partyJson.css.proposed.paragonId = 'label label-info';
                return partyJson;
            }
        } else {
            if (hasNoProposed(data)) {
                partyJson.approved.paragonId = data.approved.paragonId();
                partyJson.css.approved.paragonId = 'label label-warning';
                return partyJson;
            } else {
                var diff = calculateDiff(data.proposed, data.approved);
                var paragon_id = hasData(diff['paragonId']);

                partyJson.proposed.paragonId = data.proposed.paragonId;
                partyJson.approved.paragonId = paragon_id ? diff['paragonId'][1] : data.proposed.paragonId;
                partyJson.css.approved.paragonId = paragon_id ? 'label label-warning' : '';
                partyJson.css.proposed.paragonId = paragon_id ? 'label label-info' : '';
                return partyJson;
            }
        }

    }

    // helpers

    function hasData(suspect) {
        return _.isArray(suspect);
    }

    function hasNoApproved(suspect) {
        return _.isEmpty(suspect.approved);
    }

    function hasNoProposed(suspect) {
        return _.isEmpty(suspect.proposed);
    }

    function isNotEmpty(suspect) {
        return !_.isEmpty(suspect);
    }

    function calculateDiff(proposed, approved) {
        return $.objectDiff(ko.toJS(proposed), ko.toJS(approved));
    }

    function isOverride(suspect) {
        if (hasNoProposed(suspect)) {
            return false;
        } else {
            var approvedOverride = false;
            var proposedOverride = false;
            if(!_.isUndefined(suspect.approved)){
                approvedOverride = suspect.approved.isOverride() == true
            }
            if(!_.isUndefined(suspect.proposed)){
                proposedOverride = suspect.proposed.isOverride() == true
            }
            return _.contains([approvedOverride,proposedOverride],true)
        }
    }



});