define(['plugins/http', 'knockout', 'plugins/router', 'plugins/koplus'], function (http, ko, router) {
    return {
        storeRowState: storeRowState,
        getRowState: getRowState,
        clearRowState: clearRowState,

        getOverridesRowState: getOverridesRowState,
        storeOverridesRowState: storeOverridesRowState,

        getShowOverridesRowState: getShowOverridesRowState,
        storeShowOverridesRowState: storeShowOverridesRowState,

        storeOverride:storeOverride,
        getOverride: getOverride,
        clearOverride:clearOverride

    };


    // overrides search
    function storeOverride(row) {
        return sessionStorage.setItem('fuse[override]', row);
    }

    function getOverride() {
        return sessionStorage.getItem('fuse[override]');
    }

    function clearOverride() {
        return sessionStorage.removeItem('fuse[override]');
    }

    // set and get session storage
    function storeRowState(rowId, state) {
        return sessionStorage.setItem(rowId, state);
    }

    function getRowState(rowId) {
        return sessionStorage.getItem(rowId);
    }

    function clearRowState(rowId) {
        return sessionStorage.removeItem(rowId);
    }

    // overrides storage
    function storeOverridesRowState(rowId,state){
        return sessionStorage.setItem("fuse_overrides_" + rowId, state);
    }

    function getOverridesRowState(rowId){
        return sessionStorage.getItem("fuse_overrides_" + rowId);
    }

    function storeShowOverridesRowState(rowId,state){
        return sessionStorage.setItem("fuse_show_overrides_" + rowId, state);
    }

    function getShowOverridesRowState(rowId){
        return sessionStorage.getItem("fuse_show_overrides_" + rowId);
    }

});