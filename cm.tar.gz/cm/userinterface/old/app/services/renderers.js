define(['plugins/http', 'knockout', 'plugins/router', 'plugins/koplus'], function (http, ko, router) {
    return {
        renderListAsTable: renderListAsTable,
        renderDataAsLabel: renderDataAsLabel,
        renderCheapestToDeliverList: renderCheapestToDeliverList,
        renderGeneralDescription: renderGeneralDescription
    };

    function renderListAsTable(data) {
        var html = [];
        html.push(
            '<table style="width: auto;" class="table table-bordered table-condensed table-striped">',
            _.map(data,function (item) {
                return "<tr><td>" + item + "</td></tr>"
            }).join(""),
            "</table>"
        );
        return html.join("");
    }

    function renderDataAsLabel(data) {
        return '<span class="' + applyClass(data) + '">' + data + '</span>';
    }

    function renderCheapestToDeliverList(data) {
        var html = [];
        html.push(
            '<div class="panel panel-info">',
            '<div class="panel-heading">',
            '<h3 class="panel-title">Cheapest To Deliver</h3>',
            '</div>',
            '<div class="panel-body">',
            '<table id="cheapest_deliver" class="table table-bordered table-condensed table-striped">',
            '<thead><tr><th>Ranking</th><th>Currency</th><th>Asset</th><th>Spread</th></tr></thead>',
          _.map(data,function (item,index) {
              match = item.match(/currency = (\w\w\w) and class = (.+)\]/);
              currency = match[1];
              asset = match[2].toString().match(/(\w+)/)[1];
              spread = ~match[2].indexOf('and') ?  match[2].toString().match(/ and (.+)/)[1] : '';
              return "<tr><td>" + index + "</td><td>" + currency + "</td><td>" + asset + "</td><td>" + spread + "</td></tr>";
          }).join(""),
            "</table>",
            "</div></div>",
            "<script>$('#cheapest_deliver').dataTable({'aaSorting':[[0,'asc']]});</script>"
        );
        return html.join("");
    }

    function renderGeneralDescription(data){
      return data.replace(/\[/g,'<span class="label label-default">').replace(/\]/g,"</span>")
    }

    // helper functions

    function applyClass(data) {
        switch (data) {
            case 'true':
                return 'label label-success';
            case 'false':
                return 'label label-danger';
            default:
                return 'label label-info'
        }
    }

});