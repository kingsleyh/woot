﻿requirejs.config({
    urlArgs: "bust=" + (new Date()).getTime(),
    waitSeconds: 200,
    paths: {
        'text': '../lib/require/text',
        'durandal': '../lib/durandal/js',
        'transitions': '../lib/durandal/js/transitions',
        'knockout': '../lib/knockout/knockout-3.1.0',
        'bootstrap': '../lib/bootstrap/js/bootstrap',
        'jasny_bootstrap': '../lib/jasny-bootstrap/js/jasny-bootstrap',
        'underscore': '../lib/underscore/underscore-1.5.2',
        'datatables': '../lib/DataTables-1.9.4/media/js/jquery.dataTables.min',
        'jquery': '../lib/jquery/jquery-1.9.1.min',
        'jquery_ui': '../lib/jquery-ui-1.10.4/js/jquery-ui-1.10.4.min',
        'select2': '../lib/bootstrap/plugins/select2/js/select2',
        'Q': '../lib/Q/q',
        'plugins': '../lib/durandal/js/plugins',
        'datetimepicker': '../lib/datetimepicker/jquery.datetimepicker',
        'custom-bindings': '../lib/custom-bindings/custom-bindings',
        'oboe':'../lib/oboe/oboe'
    },
    shim: {
        'bootstrap': {
            deps: ['jquery'],
            exports: 'jQuery'
        },
        'datetimepicker': {
            deps: ['jquery','jquery_ui'],
            exports: 'datetimepicker'
        },
        'jasny_bootstrap':{
          deps: ['jquery'],
          exports: 'jasny_bootstap'
        },
        'jquery_ui': {
            deps: ['jquery'],
            exports: 'jquery_ui'
        },
        'datatables': {
            deps: ['jquery', 'jquery_ui'],
            exports: 'datatables'
        },
        'select2': {
            deps: ['jquery'],
            exports: 'select2'
        }
    }
});

define(['durandal/system', 'durandal/app', 'durandal/viewLocator'], function (system, app, viewLocator) {
    //>>excludeStart("build", true);
    system.debug(true);
    //>>excludeEnd("build");

    app.title = 'Fuse 2.0';

    app.configurePlugins({
        router: true,
        dialog: true,
        widget: true
    });

    app.start().then(function () {
        //Replace 'viewmodels' in the moduleId with 'views' to locate the view.
        //Look for partial views in a 'views' folder in the root.
        viewLocator.useConvention();

        //Show the app by setting the root view model for our application with a transition.
        app.setRoot('viewmodels/shell', 'entrance');
    });
});