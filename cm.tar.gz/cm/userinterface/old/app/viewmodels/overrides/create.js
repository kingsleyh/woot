define(['knockout', 'grid/simpleGrid', 'plugins/mapping', 'plugins/http', 'Q', 'services/natural_sort', 'services/storage', 'services/differ', 'plugins/jquery-diff', 'underscore', 'plugins/koplus', 'custom-bindings', 'jasny_bootstrap'], function (ko, SimpleGrid, mapping, http, Q, naturalSort, storage, differ) {

    ko.mapping = mapping;

    var inTestMode = ko.computed(function () {
        return eval(storage.inTestMode());
    });

    function Principal() {
        var self = this;
        self.paragonId = ko.observable();
    }

    function Counterparty() {
        var self = this;
        self.paragonId = ko.observable();
    }

    function Product(data) {
        var self = this;
        self.code = ko.observable(data);
    }

    function Trade() {
        var self = this;
        self.sourceSystem = ko.observable();
        self.tradeId = ko.observable();
    }

    function Csa() {
        var self = this;
        self.ds2 = ko.observable();
        self.ds25 = ko.observable();
        self.ds3 = ko.observable();
        self.csaId = ko.observable();
        self.expiryDate = ko.observable();
        self.user = ko.observable();
        self.comment = ko.observable();
        self.principals = ko.observableArray();
        self.counterparties = ko.observableArray();
        self.products = ko.observableArray();
        self.trades = ko.observableArray();
        self.useProducts = ko.observable(true);
        self.productClass = ko.computed(function () {
            return self.useProducts() == true ? 'btn btn-success' : 'btn btn-default'
        });
        self.tradeClass = ko.computed(function () {
            return self.useProducts() == true ? 'btn btn-default' : 'btn btn-success'
        });

        self.enableProducts = function () {
            self.useProducts(true);
            self.trades([]);
            self.products([]);
        };

        self.enableTrades = function () {
            self.useProducts(false);
            self.trades([]);
            self.products([]);
        };

        self.addPrincipal = function () {
            self.principals.push(new Principal());
        };

        self.removePrincipal = function (principal) {
            self.principals.remove(principal);
        };

        self.addCounterparty = function () {
            self.counterparties.push(new Counterparty());
        };

        self.removeCounterparty = function (counterparty) {
            self.counterparties.remove(counterparty);
        };

        self.addProduct = function () {
            self.products.push(new Product());
        };

        self.removeProduct = function (product) {
            self.products.remove(product);
        };

        self.addTrade = function () {
            self.trades.push(new Trade());
        };

        self.removeTrade = function (trade) {
            self.trades.remove(trade);
        };

        self.clear = function () {
            storage.clearOverride();
            self.csaId(undefined);
            self.ds2(undefined);
            self.ds25(undefined);
            self.ds3(undefined);
            self.csaId(undefined);
            self.expiryDate(undefined);
            self.user(undefined);
            self.comment(undefined);
            self.principals([]);
            self.counterparties([]);
            self.products([]);
            self.trades([]);
            self.useProducts(true);
        };

        self.requestError = ko.observable();
        self.hasError = ko.computed(function () {
            return !_.isEmpty(self.requestError());
        });
        self.successMessage = ko.observable();



        self.requestOverride = function () {
            self.requestError(undefined);
            self.successMessage(undefined);
            var override = {
                "recertificationDate": self.expiryDate(),
                "user": "somebody",
                "comment": self.comment(),
                "fundingNames": {"ds2": self.ds2(), "ds25": self.ds25(), "ds3": self.ds3()}
            };
            if (!_.isEmpty(self.principals())) {
                override['principals'] = self.principals();
            }
            if (!_.isEmpty(self.counterparties())) {
                override['counterparties'] = self.counterparties();
            }
            if (!_.isEmpty(self.products())) {
                override['products'] = _.map(self.products(), function (data) {
                    return data.code()
                });
            }
            if (!_.isEmpty(self.trades())) {
                override['trades'] = self.trades();
            }

//            console.log(override);

            Q.when(http.put('../../cm/overrides/csa/' + self.csaId(), override)).then(function(){
             self.successMessage('Successfully created override for csa: ' + self.csaId());
             self.clear();
            }).fail(function(error){
                self.requestError('Could not request Override for csa: ' + self.csaId() + ' due to: ' + error.status + ' ' + error.statusText + ' message: ' + error.responseText);
            }).done()
        }
    }



    var csa = new Csa();

    return {
        activate: function () {
            var fromStore = function (item) {
                var s = eval("(" + storage.getOverride() + ")");
                if (_.isNull(s)) {
                    return [];
                }
                if (!_.isUndefined(s[item])) {
                    return s[item];
                }
            };
            csa.csaId(fromStore('csaId'));
            csa.expiryDate(fromStore('recertificationDate'));
            csa.ds2(fromStore('ds2'));
            csa.ds25(fromStore('ds25'));
            csa.ds3(fromStore('ds3'));
            csa.principals(fromStore('principals'));
            csa.counterparties(fromStore('counterparties'));
            var products = fromStore('products');
            var trades = fromStore('trades');
            if(!_.isEmpty(products)){
                csa.products(_.map(fromStore('products'),function(prod){ return new Product(prod)}));
                csa.useProducts(true);
            } else {
                csa.trades(fromStore('trades'));
                csa.useProducts(false);
            }
        },
        csa: csa
    }


});
