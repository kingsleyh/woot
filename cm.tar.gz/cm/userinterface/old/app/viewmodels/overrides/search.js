define(['knockout', 'grid/simpleGrid', 'plugins/mapping', 'plugins/http', 'Q', 'services/natural_sort', 'services/storage', 'services/differ', 'plugins/jquery-diff', 'underscore', 'plugins/koplus', 'datatables', 'bootstrap', 'jasny_bootstrap'], function (ko, SimpleGrid, mapping, http, Q, naturalSort, storage, differ) {

    ko.mapping = mapping;

    function Row(data) {
        var self = this;
        ko.mapping.fromJS(data, {}, self);

        self.checkStorage = ko.computed(function () {
            var value = storage.getOverridesRowState(data.csaId);
            if (value == null) {
                return false
            }
            return value == 'true'
        });

        self.fundingNames = ko.computed(function () {
            if (_.isUndefined(data.details)) {
                return {"ds2": "", "ds25": "", "ds3": ""};
            } else {
                return _.isEmpty(data.details.fundingNames) ? {"ds2": "", "ds25": "", "ds3": ""} : data.details.fundingNames;
            }
        });

        self.principals = ko.computed(function () {
            return self.onEmpty('principals');
        });

        self.counterparties = ko.computed(function () {
            return self.onEmpty('counterparties');
        });

        self.products = ko.computed(function () {
            return self.onEmpty('products');
        });

        self.trades = ko.computed(function () {
            return self.onEmpty('trades');
        });

        self.eligibleAssets = ko.computed(function () {
            return self.onEmpty('eligibleAssets');
        });

        self.reciprocity = ko.computed(function () {
            return self.onUndefined('reciprocity');
        });

        self.isLive = ko.computed(function () {
            return self.onUndefined('isLive');
        });

        self.agreementStatus = ko.computed(function () {
            return self.onUndefined('agreementStatus');
        });

        self.documentType = ko.computed(function () {
            return self.onUndefined('documentType');
        });

        self.scope = ko.computed(function () {
            return self.onUndefined('scope');
        });

        self.isCleared = ko.computed(function () {
            return self.onUndefined('isCleared');
        });

        self.thresholds = ko.computed(function () {
            if (_.isUndefined(data.details)) {
                return {"principal": {"threshold": "", "currency": ""}, "counterparty": {"threshold": "", "currency": ""}};
            } else {
                return _.isEmpty(data.details.thresholds) ? {"principal": {"threshold": "", "currency": ""}, "counterparty": {"threshold": "", "currency": ""}} :
                    data.details.thresholds;
            }
        });

        self.onUndefined = function (item) {
            if (_.isUndefined(data.details)) {
                return "";
            } else {
                return _.isUndefined(data.details[item]) ? "" : data.details[item];
            }
        };

        self.onEmpty = function (item) {
            if (_.isUndefined(data.details)) {
                return [];
            } else {
                return _.isEmpty(data.details[item]) ? [] : data.details[item];
            }
        };

        self.subRowDetailTitle = ko.computed(function () {
            return data.csaId;
        }, self);

        self.showSubRow = ko.observable(self.checkStorage());
    }


    function FetchUrl() {
        var self = this;
        self.fetch = function (name, url) {
            return http.get(url).success(function (data) {
                    return Q.fcall(data);
                }
            );
        }
    }


    function CsaSearch() {
        var self = this;
        self.sourceSystem = ko.observable();
        self.shortCode = ko.observable();
        self.csaDetails = ko.observableArray();
        self.searchError = ko.observable();
        self.hasError = ko.computed(function () {
            return !_.isEmpty(self.searchError());
        });
        self.explain = ko.observableArray([]);

        var mapping = {
            create: function (options) {
                return new Row(options.data);
            }
        };

        self.clear = function () {
            self.sourceSystem(undefined);
            self.shortCode(undefined);
            self.csaDetails([]);
            self.searchError(undefined);
            self.explain([]);
        };

        self.searchByShortCode = function () {
            self.csaDetails([]);
            self.searchError(undefined);
            self.explain([]);
            self.explain.push('Searching for partyShortCode with sourceSystem: ' + self.sourceSystem() + ' and shortCode: ' + self.shortCode());
            Q.when(new FetchUrl().fetch('latest_party_shortcodes', "../../cm/latest/partyShortCode/" + self.sourceSystem() + "/" + self.shortCode())).then(function (data) {
                self.explain.push('Found a paragonId: ' + data.paragonId);
                return data.paragonId;
            }).then(function (paragonId) {
                self.explain.push('Searching for Party with paragonId: ' + paragonId);
                return new FetchUrl().fetch('latest_party', "../../cm/latest/party/" + paragonId);
            }).then(function (data) {
                    self.explain.push('Found ' + data.csas.length + ' Csas');
                    _.forEach(data.csas, function (csaId) {
                        Q.when(new FetchUrl().fetch('latest_csa', "../../cm/latest/csa/" + csaId)).then(function (data) {
                            var json = ko.mapping.fromJS(data, mapping);
                            self.csaDetails.push(json);
                            self.explain.push('Processing Csa: ' + data.csaId);
                        }).fail(function (error) {
//                                console.log(error);
                            self.explain.push('Could not process Csa: ' + csaId + ' due to: ' + error.status + ' ' + error.statusText);
                        })
                            .done();
                    })
                }
            ).catch(function (error) {
//                    console.log(error);
                    self.searchError(error.status + ' ' + error.statusText);
                })
                .done();
        };
    }

    var csaSearch = new CsaSearch();
    var gridViewModel = ko.observable();

    gridViewModel(new SimpleGrid({
        data: csaSearch.csaDetails,
        columns: [
            { headerText: "csa Id", rowText: "csaId" },
            { headerText: "Actions", rowText: function (item) {
                var html = [];
                html.push(
                        '<span id="actionbar_' + item.csaId() + '">&nbsp;',
                        '<a id="action_view_' + item.csaId() + '" class="view btn btn-xs btn-info" href="#overrides">View</a> ',
                        '<a id="action_override_' + item.csaId() + '" class="override btn btn-xs btn-success" href="#overrides/create">Override</a> ',
                    '</span>'
                );
                return html.join("");
            } },
            { headerText: "FundingNames", rowText: function (item) {
                var html = [];
                html.push(
                    '<table>',
                    '<tr>',
                    '<th class="fnameDisplay">DS2</th>',
                        '<td class="fnameValue"><span style="padding-left:7px;">' + item.fundingNames().ds2 + '</span></td>',
                    '</tr>',
                    '<tr>',
                    '<th class="fnameDisplay">DS2.5</th>',
                        '<td class="fnameValue"><span style="padding-left:7px;">' + item.fundingNames().ds25 + '</span></td>',
                    '</tr>',
                    '<tr>',
                    '<th class="fnameDisplay">DS3</th>',
                        '<td class="fnameValue"><span style="padding-left:7px;">' + item.fundingNames().ds3 + '</span></td>',
                    '</tr>',
                    '</table>'
                );
                return html.join("");
            } }


        ],
        pageSize: 20
    }));

    // lifecycle hook - attached
    function compositionComplete() {
//        console.log('complete');
        $("#rows").on("click", "a.view", function () {
//            console.log('clicked view');
            var context = ko.contextFor(this); //this is the element that was clicked
            if (context) {
                var csa_id = context.$parent.csaId();
                $('#actionbar_' + csa_id).toggleClass('spinner');
                var subRowState = context.$parent.showSubRow() == true;
                context.$parent.showSubRow(!subRowState);
                storage.storeOverridesRowState(csa_id, !subRowState);
                $('#actionbar_' + csa_id).toggleClass('spinner');
            }
        });

        $("#rows").on("click", "a.override", function () {
//            console.log('clicked override');
            var context = ko.contextFor(this); //this is the element that was clicked
            if (context) {
//                console.log(context.$parent);

                var row = context.$parent;

                var override = {
                    "csaId": row.csaId(),
                    "ds2": row.fundingNames().ds2,
                    "ds25": row.fundingNames().ds25,
                    "ds3": row.fundingNames().ds3,
                    "principals": row.principals(),
                    "counterparties": row.counterparties(),
                    "products": row.products(),
                    "trades": row.trades()
                };
                storage.storeOverride(JSON.stringify(override));
            }
        });
        return true;
    }

    return {
        compositionComplete: compositionComplete,
        csaSearch: csaSearch,
        gridViewModel: gridViewModel
    }


});
