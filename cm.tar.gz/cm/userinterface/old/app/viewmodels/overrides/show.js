define(['knockout', 'plugins/router', 'grid/simpleGrid', 'plugins/mapping', 'plugins/http', 'Q', 'services/natural_sort', 'services/storage', 'services/differ', 'plugins/jquery-diff', 'underscore', 'plugins/koplus', 'datatables', 'bootstrap', 'jasny_bootstrap'], function (ko, router, SimpleGrid, mapping, http, Q, naturalSort, storage, differ) {

    ko.mapping = mapping;

    function Row(data) {
        var self = this;
        ko.mapping.fromJS(data, {}, self);

        self.checkStorage = ko.computed(function () {
            var value = storage.getShowOverridesRowState(data.csaId);
            if (value == null) {
                return false
            }
            return value == 'true'
        });

        self.recertificationDate = ko.computed(function () {
            return _.isEmpty(data.recertificationDate) ? "" : data.recertificationDate;
        });

        self.fundingNames = ko.computed(function () {
            return _.isEmpty(data.fundingNames) ? {"ds2": "", "ds25": "", "ds3": ""} : data.fundingNames;
        });

        self.principals = ko.computed(function () {
            return _.isEmpty(data.principals) ? [] : data.principals;
        });

        self.counterparties = ko.computed(function () {
            return _.isEmpty(data.counterparties) ? [] : data.counterparties;
        });

        self.products = ko.computed(function () {
            return _.isEmpty(data.products) ? [] : data.products;
        });

        self.trades = ko.computed(function () {
            return _.isEmpty(data.trades) ? [] : data.trades;
        });

        self.subRowDetailTitle = ko.computed(function () {
            return data.csaId;
        }, self);

        self.showSubRow = ko.observable(self.checkStorage());
    }


    function FetchUrl() {
        var self = this;

        self.fetch = function (name, url) {

            return http.get(url).success(function (data) {
                    return Q.fcall(data);
                }
            );
        }
    }

    function TabularData() {
        var self = this;
        self.data = ko.observableArray();
    }

    // instantiate
    var tabularData = new TabularData();
    var gridViewModel = ko.observable();

    gridViewModel(new SimpleGrid({
        data: tabularData.data,
        columns: [
            { headerText: "csa Id", rowText: "csaId" },
            { headerText: "recertification Date", rowText: "recertificationDate" },
            { headerText: "Actions", rowText: function (item) {
                var html = [];
                html.push(
                        '<span id="actionbar_' + item.csaId() + '">&nbsp;',
                        '<a id="action_view_' + item.csaId() + '" class="view btn btn-xs btn-info" href="#overrides/show">View</a> ',
                        '<a id="action_modify_' + item.csaId() + '" class="modify btn btn-xs btn-warning" href="#overrides/create">Modify</a> ',
                        '<a id="action_delete_' + item.csaId() + '" class="delete btn btn-xs btn-danger" href="#overrides/show">Remove</a> ',
                    '</span>'
                );
                return html.join("");
            } },
            { headerText: "FundingNames", rowText: function (item) {
                var html = [];
                html.push(
                    '<table>',
                    '<tr>',
                    '<th class="fnameDisplay">DS2</th>',
                        '<td class="fnameValue"><span style="padding-left:7px;">' + item.fundingNames().ds2 + '</span></td>',
                    '</tr>',
                    '<tr>',
                    '<th class="fnameDisplay">DS2.5</th>',
                        '<td class="fnameValue"><span style="padding-left:7px;">' + item.fundingNames().ds25 + '</span></td>',
                    '</tr>',
                    '<tr>',
                    '<th class="fnameDisplay">DS3</th>',
                        '<td class="fnameValue"><span style="padding-left:7px;">' + item.fundingNames().ds3 + '</span></td>',
                    '</tr>',
                    '</table>'
                );
                return html.join("");
            } }


        ],
        pageSize: 20
    }));

    // lifecycle hook - attached
    function compositionComplete() {
        $("#rows").on("click", "a.view", function () {
            var context = ko.contextFor(this); //this is the element that was clicked
            if (context) {
                var csa_id = context.$parent.csaId();
                $('#actionbar_' + csa_id).toggleClass('spinner');
                var subRowState = context.$parent.showSubRow() == true;
                context.$parent.showSubRow(!subRowState);
                storage.storeShowOverridesRowState(csa_id, !subRowState);
                $('#actionbar_' + csa_id).toggleClass('spinner');
            }
        });

        $("#rows").on("click", "a.modify", function () {
            var context = ko.contextFor(this); //this is the element that was clicked
            if (context) {
//                console.log(context.$parent);

                var row = context.$parent;

                var override = {
                    "csaId": row.csaId(),
                    "ds2": row.fundingNames().ds2,
                    "ds25": row.fundingNames().ds25,
                    "ds3": row.fundingNames().ds3,
                    "recertificationDate": row.recertificationDate(),
                    "principals": row.principals(),
                    "counterparties": row.counterparties(),
                    "products": row.products(),
                    "trades": row.trades()
                };
                storage.storeOverride(JSON.stringify(override));
            }
        });

        $("#rows").on("click", "a.delete", function () {
            var context = ko.contextFor(this); //this is the element that was clicked
            if (context) {
//                console.log(context.$parent);

                var row = context.$parent;
                Q.when(http.remove('../../cm/overrides/csa/' + row.csaId())).then(function () {
                    tabularData.data.remove(row);
                }).fail(function (error) {
                    // TODO handle error
                })
                    .done();
            }
        });

        return true;
    }

    function activate() {
        var mapping = {
            create: function (options) {
                return new Row(options.data);
            }
        };
        return Q.when(new FetchUrl().fetch('latest_overrides', "../../cm/overrides/csas")).then(function (data) {
            var json = ko.mapping.fromJS(data, mapping);
            tabularData.data(json());

        }).fail(function (error) {
            // TODO handle error here.
        })
            .done();

    }

    return {
        activate: activate,
        compositionComplete: compositionComplete,
        gridViewModel: gridViewModel
    }


});
