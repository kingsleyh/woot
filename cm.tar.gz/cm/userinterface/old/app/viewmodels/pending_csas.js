﻿define(['knockout', 'grid/simpleGrid', 'plugins/mapping', 'plugins/http', 'Q', 'oboe', 'services/natural_sort', 'services/storage', 'services/differ', 'plugins/jquery-diff', 'underscore', 'plugins/koplus', 'datatables'], function (ko, SimpleGrid, mapping, http, Q, oboe, naturalSort, storage, differ) {

    ko.mapping = mapping;

    function Row(data) {
        var self = this;
        ko.mapping.fromJS(data, {}, self);

        self.isAnOverride = ko.computed(function () {
            if (_.isUndefined(data.proposed)) {
                return "No";
            }
            return data.proposed.isOverride == true ? "Yes" : "No";
        });

        self.isLive = ko.computed(function () {
            if (_.isUndefined(data.proposed)) {
                return "No";
            }
            return data.proposed.isLive == true ? "Yes" : "No";
        });

        self.fundingNames = ko.computed(function () {
            return differ.fundingNames(self);
        });

        self.thresholdData = ko.computed(function () {
            return differ.thresholdData(self);
        });

        self.assetData = ko.computed(function () {
            return differ.assetData(self);
        });

        self.tradeData = ko.computed(function () {
            if (self.hasTrades()) {
                return self.proposed.trades;
            } else {
                return ko.observableArray([]);
            }
        });

//        self.dbEntities = ko.computed(function(){
//           console.log(differ.dbEntities(self));
//        });

        self.proposedFundingNameForDisplay = ko.computed(function () {
            if (!_.isEmpty(self.proposed)) {
                return {'display': 'DS2.5', 'value': self.proposed.fundingNamesContext.fundingNames['ds25']};
            } else {
                return {'display': 'DS2.5', 'value': ko.observable('')};
            }
        }, self);

        self.approvedFundingNameForDisplay = ko.computed(function () {
            if (!_.isEmpty(self.approved)) {
                return {'display': 'DS2.5', 'value': self.approved.fundingNamesContext.fundingNames['ds25']};
            } else {
                return {'display': 'DS2.5', 'value': ko.observable('')};
            }
        }, self);

        self.subRowDetailTitle = ko.computed(function () {
            return data.csaId;
        }, self);


        self.hasTrades = ko.computed(function () {
            if (!_.isEmpty(self.proposed)) {
                return !_.isEmpty(self.proposed.trades);
            } else {
                return false;
            }
        });

        self.hasThresholds = ko.computed(function () {
            if (self.hasProposed()) {
                return !_.isEmpty(self.proposed.thresholds);
            } else {
                return false;
            }
        });

        self.hasProposed = ko.computed(function () {
            return !_.isEmpty(self.proposed);
        });

        self.checkStorage = ko.computed(function () {
            var value = storage.getRowState(data.csaId);
            if (value == null) {
                return false
            }
            return value == 'true'
        });
        self.status = ko.observable("Pending Review");
        self.showSubRow = ko.observable(self.checkStorage());
    }

    function TabularData() {
        var self = this;
        self.data = ko.observableArray();
    }

    // instantiate
    var tabularData = new TabularData();
    var gridViewModel = ko.observable();

    gridViewModel(new SimpleGrid({
        data: tabularData.data,
        columns: [
            { headerText: "Csa Id", rowText: "csaId" },
            { headerText: "Is Override?", rowText: function (item) {
                return item.isAnOverride() == 'Yes' ? '<span class="label label-primary">' + item.isAnOverride() + '</span>' :
                    '<span class="label label-default">' + item.isAnOverride() + '</span>';
            } },
            { headerText: "Actions", rowText: function (item) {
                var html = [];
                html.push(
                        '<span id="actionbar_' + item.csaId() + '">&nbsp;',
                        '<a id="action_view_' + item.csaId() + '" class="view btn btn-xs btn-info" href="#">View</a> ',
                        '<a id="action_approve_' + item.csaId() + '" class="approve btn btn-xs btn-success" href="#">Approve</a> ',
                        '<a id="action_reject_' + item.csaId() + '" class="reject btn btn-xs btn-warning" href="#">Reject</a> ',
                    '</span>'
                );
                return html.join("");
            } },
            { headerText: "Proposed", rowText: function (item) {
                var html = [];
                html.push(
                    '<table>',
                    '<tr>',
                        '<th class="fnameDisplay">' + item.proposedFundingNameForDisplay().display + '</th>',
                        '<td class="fnameValue"><span style="padding-left:3px;padding-right:3px;color:#cdcdcd">|</span>' + item.proposedFundingNameForDisplay().value() + '</td>',
                    '</tr>',
                    '</table>'
                );
                return html.join("");
            } },
            { headerText: "Approved", rowText: function (item) {
                var html = [];
                html.push(
                    '<table>',
                    '<tr>',
                        '<th class="fnameDisplay">' + item.approvedFundingNameForDisplay().display + '</th>',
                        '<td class="fnameValue"><span style="padding-left:3px;padding-right:3px;color:#cdcdcd">|</span>' + item.approvedFundingNameForDisplay().value() + '</td>',
                    '</tr>',
                    '</table>'
                );
                return html.join("");
            } },
            { headerText: "Is Live?", rowText: function (item) {
                return item.isLive() == 'Yes' ? '<span class="label label-default">' + item.isLive() + '</span>' :
                    '<span class="label label-primary">' + item.isLive() + '</span>';
            } }

        ],
        pageSize: 20
    }));


    var current = this;
    current.sizeColor = ko.observable('label-warning');

    function fetch() {
        var mapping = {
            create: function (options) {
                return new Row(options.data);
            }
        };
        tabularData.data([]);
        current.sizeColor('label-warning');
        oboe('../../cm/pending/csas').node('{csaId}', function (data) {
            var json = ko.mapping.fromJS(data, mapping);
            tabularData.data.push(json);
            return oboe.drop;
        }).done(function(data){
            current.sizeColor('label-primary');
        });
    }

    // lifecycle hook - attached
    function attached() {
        fetch();
    }

    // lifecycle hook - attached
    function compositionComplete() {

        $("#rows").on("click", "a.view", function () {
            var context = ko.contextFor(this); //this is the element that was clicked
            if (context) {
                var csa_id = context.$parent.csaId();
                $('#actionbar_' + csa_id).toggleClass('spinner');
                var subRowState = context.$parent.showSubRow() == true;
                context.$parent.showSubRow(!subRowState);
                storage.storeRowState(csa_id, !subRowState);
                $('#actionbar_' + csa_id).toggleClass('spinner');
            }
        });

        $("#rows").on("click", "a.approve", function () {
            var context = ko.contextFor(this); //this is the element that was clicked
            if (context) {
                var change_id = context.$parent.changeId();
                var csa_id = context.$parent.csaId();
                var action_set = {'changes': [
                    {'changeId': change_id, 'action': 'approve', 'user': 'BillyBob'}
                ]};
                $('#actionbar_' + csa_id).addClass('spinner');
                $('#action_approve_' + csa_id).hide();
                $('#action_reject_' + csa_id).hide();
                $('#action_view_' + csa_id).hide();
                http.post('../../cm/actionset', action_set)
                    .success(function () {
//                        console.log('approved it')
                    })
                    .error(function (error) {
//                        console.log('error it');
//                        console.log(error.responseText);
                    }).
                    complete(function () {
                        return fetch();
                    });
                storage.clearRowState(csa_id);
            }

        });

        $("#rows").on("click", "a.reject", function () {
            var context = ko.contextFor(this); //this is the element that was clicked
            if (context) {
                var change_id = context.$parent.changeId();
                var csa_id = context.$parent.csaId();
                var action_set = {'changes': [
                    {'changeId': change_id, 'action': 'reject', 'user': 'BillyBob'}
                ]};
                $('#actionbar_' + csa_id).addClass('spinner');
                $('#action_approve_' + csa_id).hide();
                $('#action_reject_' + csa_id).hide();
                $('#action_view_' + csa_id).hide();
                http.post('../../cm/actionset', action_set)
                    .success(function () {
//                        console.log('rejected it')
                    })
                    .error(function (error) {
//                        console.log('error it');
//                        console.log(error.responseText);
                    }).
                    complete(function () {
                        return fetch();
                    });
                storage.clearRowState(csa_id);
            }
        });

        return true;
    }

    function Sorting() {
        var self = this;
        self.csa_id = ko.observable(false);

        self.applySorting = function (data) {
            if (data.headerText == 'Csa Id') {
                $('.sortings').hide();
                if (self.csa_id() == true) {
                    self.csa_id(false);
                    $('#col_down_Csa_Id').show();
                    tabularData.data.sort(function (a, b) {
                        return naturalSort(a.csaId(), b.csaId(), { insensitive: true, desc: true });
                    });
                } else {
                    self.csa_id(true);
                    $('#col_up_Csa_Id').show();
                    tabularData.data.sort(function (a, b) {
                        return naturalSort(a.csaId(), b.csaId(), { insensitive: true, desc: false });
                    });
                }
            }
        };
    }

    var sorting = new Sorting();

    return {
        attached: attached,
        compositionComplete: compositionComplete,
        tabular: tabularData,
        gridViewModel: gridViewModel,
        SimpleGrid: SimpleGrid,
        sizeColor: current.sizeColor,
        loadData: function(){
           fetch();
        },
        applySorting: function (data) {
            return sorting.applySorting(data);
        }
    }

});
