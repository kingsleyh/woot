define(['plugins/router', 'knockout'], function (router, ko) {
    var childRouter = router.createChildRouter()
        .makeRelative({
            moduleId: 'viewmodels/overrides',
            fromParent: true
        }).map([
            { route: ['', 'search'], title: 'CSA Search', moduleId: 'search', nav: true },
            { route: ['create'], title: 'Request Override', moduleId: 'create', nav: true },
            { route: ['show'], title: 'Show Overrides', moduleId: 'show', nav: true }
        ]).buildNavigationModel();

    return {
        router: childRouter
    };
});