define(['knockout', 'plugins/mapping', 'plugins/http', 'Q', 'services/storage', 'services/renderers', 'underscore', 'plugins/koplus', 'jquery_ui', 'datatables'], function (ko, mapping, http, Q, storage, renderers) {

    ko.mapping = mapping;

    function Explain() {
        var self = this;
        self.data = ko.observable();
        self.hasData = ko.computed(function () {
            return self.data() != undefined;
        });
        self.csaId = ko.observable();
        self.methodology = ko.observable();
        self.methodologies = ko.observableArray(['DS2', 'DS25', 'DS3']);
    }

    var explain = new Explain();

    return {
        showExplain: function () {
            explain.data(undefined);
            Q.when(http.get("../../cm/explain/latest/csa/" + explain.csaId() + "/" + explain.methodology()).success(function (data) {
                explain.data(ko.mapping.fromJS(data));
            }));
        },
        explain: explain,
        formatResult: function (data) {
            if (_.isArray(data)) {
                if (~data[0].indexOf("currency")) {
                    return renderers.renderCheapestToDeliverList(data);
                } else {
                    return renderers.renderListAsTable(data);
                }
            } else {
                return renderers.renderDataAsLabel(data);
            }
        },
        formatDescription: function (data) {
            if (~data.indexOf("[")) {
                return renderers.renderGeneralDescription(data);
            } else {
                return data;
            }
        }
    }

});