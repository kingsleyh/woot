define(['plugins/router', 'durandal/app'], function (router, app) {
    return {
        router: router,
        activate: function () {
            router.map([
                { route: ['','pending_csas'], title:'Pending CSAs', moduleId: 'viewmodels/pending_csas', nav: true },
                { route: ['pending_parties'], title:'Pending Parties', moduleId: 'viewmodels/pending_parties', nav: true },
                { route: ['explain'], title:'Explain', moduleId: 'viewmodels/explain', nav: true },
                { route: ['overrides*details'], title:'Overrides', moduleId: 'viewmodels/overrides',hash: '#overrides', nav: true },
                { route: ['differences'], title:'Differences', moduleId: 'viewmodels/differences', nav: true }
            ]).buildNavigationModel();

            return router.activate();
        }
    };
});