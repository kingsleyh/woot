﻿define(['knockout', 'grid/simpleGrid', 'plugins/mapping', 'plugins/http', 'Q', 'oboe','services/storage', 'services/differ', 'plugins/jquery-diff', 'underscore', 'plugins/koplus', 'datatables'], function (ko, SimpleGrid, mapping, http, Q, oboe, storage, differ) {

    ko.mapping = mapping;

    function Row(data) {
        var self = this;
        ko.mapping.fromJS(data, {}, self);

        self.parties = ko.computed(function () {
            return differ.parties(self);
        });

        self.source = ko.computed(function () {
            return self.partyShortCode.sourceSystem();
        });

        self.code = ko.computed(function () {
            return self.partyShortCode.shortCode();
        });

        self.partyData = ko.observable();

        self.subRowDetailTitle = ko.computed(function () {
            if (_.isEmpty(self.proposed)) {
                if (_.isEmpty(self.approved)) {
                    return ''
                } else {
                    return self.approved.paragonId();
                }
            } else {
                return self.proposed.paragonId();
            }
        }, self);

        self.change_number = ko.computed(function () {
            return data.changeId.replace(/:/g, '_');
        });

        self.checkStorage = ko.computed(function () {
            var value = storage.getRowState(data.changeId);
            if (value == null) {
                return false
            }
            return value == 'true'
        });
        self.status = ko.observable("Pending Review");
        self.showSubRow = ko.observable(self.checkStorage());

        if (self.showSubRow()) {
            fetchPartyData(self.proposed.paragonId(), self);
        }

    }

    function TabularData() {
        var self = this;
        self.data = ko.observableArray();
    }

    // instantiate
    var tabularData = new TabularData();
    var gridViewModel = ko.observable();

    gridViewModel(new SimpleGrid({
        data: tabularData.data,
        columns: [
            { headerText: "source", rowText: "source" },
            { headerText: "code", rowText: function (item) {
                return item.code()
            } },
            { headerText: "Actions", rowText: function (item) {
                var html = [];
                html.push(
                        '<span id="actionbar_' + item.change_number() + '">&nbsp;',
                        '<a id="action_view_' + item.change_number() + '" class="view btn btn-xs btn-info" href="#pending_parties">View</a> ',
                        '<a id="action_approve_' + item.change_number() + '" class="approve btn btn-xs btn-success" href="#pending_parties">Approve</a> ',
                        '<a id="action_reject_' + item.change_number() + '" class="reject btn btn-xs btn-warning" href="#pending_parties">Reject</a> ',
                    '</span>'
                );
                return html.join("");
            } },
            { headerText: "Proposed", rowText: function (item) {
                if (_.isEmpty(item.parties().proposed['paragonId'])) {
                    return '';
                } else {
                    var html = [];
                    html.push(
                        '<table><tr><th class="fnameDisplay"><span style="padding-right:10px;">paragonId</span></th><td class="fnameValue">',
                            '<span class="' + item.parties().css.proposed['paragonId'] + '">' + item.parties().proposed['paragonId']() + '</span>',
                        '</td></tr></table>'
                    );
                    return html.join("");
                }
            } },
            { headerText: "Approved", rowText: function (item) {
                if (_.isEmpty(item.parties().approved['paragonId'])) {
//                    console.log(1);
                    return '';
                } else {
//                    console.log(2);
//                    console.log(item.parties());
                    var html = [];
                    html.push(
                        '<table><tr><th class="fnameDisplay"><span style="padding-right:10px;">paragonId</span></th><td class="fnameValue">',
                            '<span class="' + item.parties().css.approved['paragonId'] + '">' + item.parties().approved['paragonId'] + '</span>',
                        '</td></tr></table>'
                    );
                    return html.join("");
                }
            } }

        ],
        pageSize: 20
    }));

    var current = this;
    current.sizeColor = ko.observable('label-warning');

    function fetch() {
        var mapping = {
            create: function (options) {
                return new Row(options.data);
            }
        };

        tabularData.data([]);
        current.sizeColor('label-warning');
        oboe('../../cm/pending/partyShortCodes').node('{partyShortCode}', function (data) {
            var json = ko.mapping.fromJS(data, mapping);
            tabularData.data.push(json);
            return oboe.drop;
        }).done(function(data){
            current.sizeColor('label-primary');
        });


    }

    function fetchPartyData(paragonId, container) {
        return Q.when(http.get("../../cm/latest/party/" + paragonId).success(function (data) {
            var json = ko.mapping.fromJS(data, {});
            container.partyData(json);
        }));
    }


    // lifecycle hook - attached
    function attached() {
        fetch();
    }

    function compositionComplete() {

        $("#rows").on("click", "a.view", function () {
            var context = ko.contextFor(this); //this is the element that was clicked
            if (context) {
                var change_number = context.$parent.change_number();
                var changeId = context.$parent.changeId();
                $('#actionbar_' + change_number).toggleClass('spinner');
                var subRowState = context.$parent.showSubRow() == true;
                if (!subRowState) {
                    if (_.isEmpty(context.$parent.proposed)) {
                        if (_.isEmpty(context.$parent.approved)) {
                            ''
                        } else {
                            fetchPartyData(context.$parent.approved['paragonId'](), context.$parent);
                        }
                    } else {
                        fetchPartyData(context.$parent.proposed['paragonId'](), context.$parent);
                    }
                }
                context.$parent.showSubRow(!subRowState);
                storage.storeRowState(changeId, !subRowState);
                $('#actionbar_' + change_number).toggleClass('spinner');
            }
        });

        $("#rows").on("click", "a.approve", function () {
            var context = ko.contextFor(this); //this is the element that was clicked
            if (context) {
                var change_number = context.$parent.change_number();
                var change_id = context.$parent.changeId();
                var action_set = {'changes': [
                    {'changeId': change_id, 'action': 'approve', 'user': 'BillyBob'}
                ]};
                $('#actionbar_' + change_number).addClass('spinner');
                $('#action_approve_' + change_number).hide();
                $('#action_reject_' + change_number).hide();
                $('#action_view_' + change_number).hide();
                http.post('../../cm/actionset', action_set)
                    .success(function () {
//                        console.log('approved it')
                    })
                    .error(function (error) {
//                        console.log('error it');
//                        console.log(error.responseText);
                    }).
                    complete(function () {
                        fetch();
                    });
                storage.clearRowState(change_id);
            }
        });

        $("#rows").on("click", "a.reject", function () {
            var context = ko.contextFor(this); //this is the element that was clicked
            if (context) {
                var change_number = context.$parent.change_number();
                var change_id = context.$parent.changeId();
                var action_set = {'changes': [
                    {'changeId': change_id, 'action': 'reject', 'user': 'BillyBob'}
                ]};
                $('#actionbar_' + change_number).addClass('spinner');
                $('#action_approve_' + change_number).hide();
                $('#action_reject_' + change_number).hide();
                $('#action_view_' + change_number).hide();
                http.post('../../cm/actionset', action_set)
                    .success(function () {
//                        console.log('rejected it')
                    })
                    .error(function (error) {
//                        console.log('error it');
//                        console.log(error.responseText);
                    }).
                    complete(function () {
                        fetch();
                    });
                storage.clearRowState(change_id);
            }
        });
    }

    function Sorting() {
        var self = this;
        self.source = ko.observable(false);
        self.code = ko.observable(false);

        this.applySorting = function (data) {
            if (data.headerText == 'source') {
                $('.sortings').hide();
                if (self.source() == true) {
                    self.source(false);
                    $('#col_down_source').show();
                    $('#col_down_code').show();
                    tabularData.data.sort(function (left, right) {
                        return [left.source(), left.code()] === [right.source(), right.code()] ? 0 : ([left.source(), left.code()] < [right.source(), right.code()] ? -1 : 1);
                    });
                } else {
                    self.source(true);
                    $('#col_up_source').show();
                    $('#col_up_code').show();
                    tabularData.data.sort(function (left, right) {
                        return [left.source(), left.code()] === [right.source(), right.code()] ? 0 : ([left.source(), left.code()] > [right.source(), right.code()] ? -1 : 1);
                    });
                }
            } else if (data.headerText == 'code') {
                $('.sortings').hide();
                if (self.code() == true) {
                    self.code(false);
                    $('#col_down_source').show();
                    $('#col_down_code').show();
                    tabularData.data.sort(function (left, right) {
                        return left.code() === right.code() ? 0 : (left.code() < right.code() ? -1 : 1);
                    });
                } else {
                    self.code(true);
                    $('#col_up_source').show();
                    $('#col_up_code').show();
                    tabularData.data.sort(function (left, right) {
                        return left.code() === right.code() ? 0 : (left.code() > right.code() ? -1 : 1);
                    });
                }
            }
        }
    }

    var sorting = new Sorting();

    return {
        attached: attached,
        compositionComplete: compositionComplete,
        tabular: tabularData,
        gridViewModel: gridViewModel,
        SimpleGrid: SimpleGrid,
        sizeColor: current.sizeColor,
        loadData: function(){
            fetch();
        },
        applySorting: function (data) {
            return sorting.applySorting(data)
        }
    }

});
