﻿define(['knockout', 'grid/simpleGrid', 'plugins/mapping', 'plugins/http', 'Q', 'oboe', 'services/natural_sort', 'services/storage', 'services/differ', 'plugins/jquery-diff', 'underscore', 'plugins/koplus', 'datatables'], function (ko, SimpleGrid, mapping, http, Q, oboe, naturalSort, storage, differ) {

    ko.mapping = mapping;

    function TabularData() {
        var self = this;
        self.data = ko.observableArray();
    }

    // instantiate
    var tabularData = new TabularData();
    var gridViewModel = ko.observable();

    var current = this;
    current.sizeColor = ko.observable('label-warning');

    function fetch() {
        tabularData.data([]);
        current.sizeColor('label-warning');
        oboe('../../../reports/differences').node('{nextCsaId}', function (data) {
            var json = ko.mapping.fromJS(data, {});
            tabularData.data.push(json);
            return oboe.drop;
        }).done(function (data) {
            current.sizeColor('label-primary');
        });
    }

    gridViewModel(new SimpleGrid({
        data: tabularData.data,
        pageSize: 20
    }));

    function attached() {
        fetch();
    }

    return {
        attached: attached,
        gridViewModel: gridViewModel,
        sizeColor: current.sizeColor,
        loadData: function () {
            fetch();
        },
        SimpleGrid: SimpleGrid
    }


});
