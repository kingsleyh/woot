'use strict';

fuseApp.controller('NavController',
    function NavController($scope, $location, userService) {
        userService.async().then(function(d) {
            $scope.user = d;
        },function(error){
            $scope.user = '';
        });
    }
);