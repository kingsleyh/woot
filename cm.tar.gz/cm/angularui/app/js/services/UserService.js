'use strict';

fuseApp.factory('userService', function ($http) {

    function capitaliseFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }

    var userService = {
        async: function () {
            var promise = $http.get('/auth/whoamia').then(function (response) {
                var data = response.data.split("@")[0].split(".");
                var firstNameData = data[0].split(" ");
                var firstName = capitaliseFirstLetter(firstNameData[firstNameData.length - 1]);
                var lastName = capitaliseFirstLetter(data[data.length - 1]);
                return firstName + " " + lastName;
            });
            return promise;
        }
    };
    return userService;
});
