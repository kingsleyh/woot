'use strict';

fuseApp.factory('explainService', ['$resource', function ($resource) {
    return $resource('/cm/explain/latest/csa/:csaId/:methodology', {csaId:'@csaId',methodology:'@methodology'});
}]);
