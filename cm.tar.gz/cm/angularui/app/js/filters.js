'use strict';

fuseApp.filter('formatDescription', function ($sce) {
    return function (data) {
        if (~data.indexOf("[")) {
            return $sce.trustAsHtml(renderGeneralDescription(data));
        } else {
            return $sce.trustAsHtml(data);
        }
    };
});

fuseApp.filter('formatResult', function ($sce) {
    return function (data) {
        if (_.isArray(data)) {
            if (~data[0].indexOf("currency")) {
                return $sce.trustAsHtml(renderCheapestToDeliverList(data));
            } else {
                return $sce.trustAsHtml(renderListAsTable(data));
            }
        } else {
            return $sce.trustAsHtml(renderDataAsLabel(data));
        }
    };
});

function renderListAsTable(data) {
    var html = [];
    html.push(
        '<table style="width: auto;" class="table table-bordered table-condensed table-striped">',
        _.map(data, function (item) {
            return "<tr><td>" + item + "</td></tr>"
        }).join(""),
        "</table>"
    );
    return html.join("");
}

function renderDataAsLabel(data) {
    return '<span class="' + applyClass(data) + '">' + data + '</span>';
}

function renderCheapestToDeliverList(data) {
    var html = [];
    html.push(
        '<div class="panel panel-info">',
        '<div class="panel-heading">',
        '<h3 class="panel-title">Cheapest To Deliver</h3>',
        '</div>',
        '<div class="panel-body">',
        '<table id="cheapest_deliver" class="table table-bordered table-condensed table-striped">',
        '<thead><tr><th>Ranking</th><th>Currency</th><th>Asset</th><th>Spread</th></tr></thead>',
        _.map(data, function (item, index) {

            var currencyMatch = item.match(/currency = (\w\w\w)/);
            var currency = _.isNull(currencyMatch) ? "" : currencyMatch[1];

            var asset = "";
            var spread = "";
            var assetSpreadMatch = item.match(/class = (.+) and (.+)]/);
            if (_.isNull(assetSpreadMatch)) {
                var assetMatch = item.match(/class = (.+)]/);
                asset = _.isNull(assetMatch) ? "" : assetMatch[1];
            } else {
                asset = assetSpreadMatch[1];
                spread = assetSpreadMatch[2];
            }
            return "<tr><td>" + index + "</td><td>" + currency + "</td><td>" + asset + "</td><td>" + spread + "</td></tr>";
        }).join(""),
        "</table>",
        "</div></div>",
        "<script>$('#cheapest_deliver').dataTable({'aaSorting':[[0,'asc']]});</script>"
    );
    return html.join("");
}

function renderGeneralDescription(data) {
    return data.replace(/\[/g, '<span class="label label-default">').replace(/\]/g, "</span>")
}

// helper functions

function applyClass(data) {
    switch (data) {
        case 'true':
            return 'label label-success';
        case 'false':
            return 'label label-danger';
        default:
            return 'label label-info'
    }
}