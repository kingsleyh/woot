'use strict';

var fuseApp = angular.module('fuseApp', ['ngResource']);